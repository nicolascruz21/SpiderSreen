/*
	Hyperspace by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

function hideImageOnSmallScreen() {
    const imagem = document.getElementById('imagemquedevesumir'); // Obtém a imagem pelo ID

    // Verifica se a largura da tela é menor que 768 pixels (pode ajustar esse valor)
    if (window.innerWidth < 768) {
      imagem.style.display = 'none'; // Oculta a imagem
    } else {
      imagem.style.display = 'block'; // Mostra a imagem
    }
  }

  // Chama a função ao carregar a página
  window.addEventListener('load', hideImageOnSmallScreen);

  // Chama a função sempre que a tela for redimensionada
  window.addEventListener('resize', hideImageOnSmallScreen);

const sliderContainer = document.querySelector('.slider-container');
        const sliderItems = document.querySelectorAll('.slider-container li');
        const nextButton = document.querySelector('.slider-nav-next');
        const prevButton = document.querySelector('.slider-nav-prev');
        const indicatorButtons = document.querySelectorAll('.slider-indicators button');

        let currentIndex = 0;

        function goToSlide(index) {
            sliderItems[currentIndex].style.display = 'none';
            indicatorButtons[currentIndex].classList.remove('active');

            currentIndex = (index + sliderItems.length) % sliderItems.length;

            sliderItems[currentIndex].style.display = 'block';
            indicatorButtons[currentIndex].classList.add('active');
        }

        function nextSlide() {
            goToSlide(currentIndex + 1);
        }

        function prevSlide() {
            goToSlide(currentIndex - 1);
        }

        nextButton.addEventListener('click', nextSlide);
        prevButton.addEventListener('click', prevSlide);

        setInterval(nextSlide, 9000); // Mude de slide a cada 6 segundos

document.addEventListener("DOMContentLoaded", function () {
    // Selecione todas as imagens dentro das divs com a classe "services-images"
    var imageElements = document.querySelectorAll(".services-images .service-item img");

    // Adicione um ouvinte de evento de mouseover para cada imagem
    imageElements.forEach(function (img) {
      img.addEventListener("mouseover", function () {
        // Quando o mouse passar por cima da imagem, a animação CSS será acionada automaticamente
        // Não é necessário código JavaScript adicional para a animação
      });
    });
  });

  document.addEventListener("DOMContentLoaded", function () {
    // Selecione todos os ícones dentro da seção com o ID "two"
    var iconElements = document.querySelectorAll("#two .links p .image img");

    // Adicione um ouvinte de evento de mouseover para cada ícone
    iconElements.forEach(function (img) {
      img.addEventListener("mouseover", function () {
        // Quando o mouse passar por cima do ícone, a animação CSS será acionada automaticamente
        // Não é necessário código JavaScript adicional para a animação
      });
    });
  });


  document.addEventListener("DOMContentLoaded", function () {
    // Selecione todos os elementos com a classe "image" dentro da seção com o ID "two"
    var imageElements = document.querySelectorAll("#two .links p .image");

    // Adicione um ouvinte de evento de mouseover para cada elemento
    imageElements.forEach(function (element) {
      element.addEventListener("mouseover", function () {
        // Quando o mouse passar por cima do elemento, a animação CSS será acionada automaticamente
        // Não é necessário código JavaScript adicional para a animação
      });
    });
  });

(function($) {

	var	$window = $(window),
		$body = $('body'),
		$sidebar = $('#sidebar');

	// Breakpoints.
		breakpoints({
			xlarge:   [ '1281px',  '1680px' ],
			large:    [ '981px',   '1280px' ],
			medium:   [ '737px',   '980px'  ],
			small:    [ '481px',   '736px'  ],
			xsmall:   [ null,      '480px'  ]
		});

	// Hack: Enable IE flexbox workarounds.
		if (browser.name == 'ie')
			$body.addClass('is-ie');

	// Play initial animations on page load.
		$window.on('load', function() {
			window.setTimeout(function() {
				$body.removeClass('is-preload');
			}, 100);
		});

	// Forms.

		// Hack: Activate non-input submits.
			$('form').on('click', '.submit', function(event) {

				// Stop propagation, default.
					event.stopPropagation();
					event.preventDefault();

				// Submit form.
					$(this).parents('form').submit();

			});

	// Sidebar.
		if ($sidebar.length > 0) {

			var $sidebar_a = $sidebar.find('a');

			$sidebar_a
				.addClass('scrolly')
				.on('click', function() {

					var $this = $(this);

					// External link? Bail.
						if ($this.attr('href').charAt(0) != '#')
							return;

					// Deactivate all links.
						$sidebar_a.removeClass('active');

					// Activate link *and* lock it (so Scrollex doesn't try to activate other links as we're scrolling to this one's section).
						$this
							.addClass('active')
							.addClass('active-locked');

				})
				.each(function() {

					var	$this = $(this),
						id = $this.attr('href'),
						$section = $(id);

					// No section for this link? Bail.
						if ($section.length < 1)
							return;

					// Scrollex.
						$section.scrollex({
							mode: 'middle',
							top: '-20vh',
							bottom: '-20vh',
							initialize: function() {

								// Deactivate section.
									$section.addClass('inactive');

							},
							enter: function() {

								// Activate section.
									$section.removeClass('inactive');

								// No locked links? Deactivate all links and activate this section's one.
									if ($sidebar_a.filter('.active-locked').length == 0) {

										$sidebar_a.removeClass('active');
										$this.addClass('active');

									}

								// Otherwise, if this section's link is the one that's locked, unlock it.
									else if ($this.hasClass('active-locked'))
										$this.removeClass('active-locked');

							}
						});

				});

		}

	// Scrolly.
		$('.scrolly').scrolly({
			speed: 1000,
			offset: function() {

				// If <=large, >small, and sidebar is present, use its height as the offset.
					if (breakpoints.active('<=large')
					&&	!breakpoints.active('<=small')
					&&	$sidebar.length > 0)
						return $sidebar.height();

				return 0;

			}
		});

	// Spotlights.
		$('.spotlights > section')
			.scrollex({
				mode: 'middle',
				top: '-10vh',
				bottom: '-10vh',
				initialize: function() {

					// Deactivate section.
						$(this).addClass('inactive');

				},
				enter: function() {

					// Activate section.
						$(this).removeClass('inactive');

				}
			})
			.each(function() {

				var	$this = $(this),
					$image = $this.find('.image'),
					$img = $image.find('img'),
					x;

				// Assign image.
					$image.css('background-image', 'url(' + $img.attr('src') + ')');

				// Set background position.
					if (x = $img.data('position'))
						$image.css('background-position', x);

				// Hide <img>.
					$img.hide();

			});

	// Features.
		$('.features')
			.scrollex({
				mode: 'middle',
				top: '-20vh',
				bottom: '-20vh',
				initialize: function() {

					// Deactivate section.
						$(this).addClass('inactive');

				},
				enter: function() {

					// Activate section.
						$(this).removeClass('inactive');

				}
			});

})(jQuery);